const svgGroup = {
  LightIcon: `<svg width='24' height='24' viewBox='0 0 24 24' fill='black'>
    <path d='M12 18C10.4087 18 8.88258 17.3679 7.75736 16.2426C6.63214 15.1174 6 13.5913 6 12C6 10.4087 6.63214 8.88258 7.75736 7.75736C8.88258 6.63214 10.4087 6 12 6C13.5913 6 15.1174 6.63214 16.2426 7.75736C17.3679 8.88258 18 10.4087 18 12C18 13.5913 17.3679 15.1174 16.2426 16.2426C15.1174 17.3679 13.5913 18 12 18ZM12 16C13.0609 16 14.0783 15.5786 14.8284 14.8284C15.5786 14.0783 16 13.0609 16 12C16 10.9391 15.5786 9.92172 14.8284 9.17157C14.0783 8.42143 13.0609 8 12 8C10.9391 8 9.92172 8.42143 9.17157 9.17157C8.42143 9.92172 8 10.9391 8 12C8 13.0609 8.42143 14.0783 9.17157 14.8284C9.92172 15.5786 10.9391 16 12 16V16ZM11 1H13V4H11V1ZM11 20H13V23H11V20ZM3.515 4.929L4.929 3.515L7.05 5.636L5.636 7.05L3.515 4.93V4.929ZM16.95 18.364L18.364 16.95L20.485 19.071L19.071 20.485L16.95 18.364ZM19.071 3.514L20.485 4.929L18.364 7.05L16.95 5.636L19.071 3.515V3.514ZM5.636 16.95L7.05 18.364L4.929 20.485L3.515 19.071L5.636 16.95V16.95ZM23 11V13H20V11H23ZM4 11V13H1V11H4Z' />
  </svg>`,
  DarkIcon: `<svg width='24' height='24' viewBox='0 0 24 24' fill='white'>
    <path d='M11.38 2.01953C10.6431 2.70615 10.0521 3.53416 9.64219 4.45415C9.23227 5.37414 9.01185 6.36728 8.99408 7.37431C8.97632 8.38133 9.16156 9.38163 9.53877 10.3155C9.91598 11.2494 10.4774 12.0977 11.1896 12.8099C11.9018 13.5221 12.7501 14.0835 13.684 14.4608C14.6179 14.838 15.6182 15.0232 16.6252 15.0054C17.6323 14.9877 18.6254 14.7673 19.5454 14.3573C20.4654 13.9474 21.2934 13.3564 21.98 12.6195C21.662 17.8545 17.316 22.0005 12.001 22.0005C6.477 22.0005 2 17.5235 2 12.0005C2 6.68553 6.146 2.33953 11.38 2.01953Z' />
  </SvgIcon>`,
  logSvg: `<svg
      aria-hidden='true'
      className='SvgIcon-root SvgIcon-fontSizeMedium '
      color='var(--color-text-third)'
      fill='none'
      focusable='false'
      height='27'
      style='height: 40px; width: 120px;'
      viewBox='0 0 89 27'
      width='89'
    >
      <path
        clip-rule='evenodd'
        d='M33.2461 13.1402H19.2495L22.2249 17.7118L11.3922 26.0863L33.2461 13.2211V13.1402ZM11.0988 26.2683V0.740234L0.0356445 17.732L11.0988 26.2683ZM35.2363 26.1875V13.1807H37.4154V24.4074H40.3908V26.1875H35.2363ZM88.6455 15.6486V17.7928H86.5293V15.6283C86.5921 14.6372 84.5387 14.5967 84.6854 15.6283V23.659C84.6854 24.1647 84.9578 24.4277 85.5654 24.4277C86.1311 24.4277 86.5293 24.1647 86.5293 23.659V21.4541H85.6073V19.674H88.6455V23.6792C88.6455 25.257 87.556 26.2887 85.5654 26.2887C83.5749 26.2887 82.4853 25.2368 82.4853 23.6792V15.6486C82.4853 14.091 83.5749 13.0391 85.5654 13.0391C87.556 13.0391 88.6455 14.0708 88.6455 15.6486ZM79.1119 20.2809C79.07 19.0874 79.049 17.9951 79.049 16.9836H79.0281V13.1605H81.0186V26.1875H78.7138L76.6604 18.9256C76.7023 20.1393 76.7233 21.2923 76.7233 22.3441V26.1875H74.7327V13.1605H77.1004L79.1119 20.2809ZM73.1403 26.1673H70.9612V13.1403H73.1403V26.1673ZM66.582 19.411C67.1058 19.411 67.3782 19.1481 67.3782 18.6424V15.7093C67.3782 15.2036 67.1058 14.9406 66.582 14.9406H65.5972V19.411H66.582ZM69.5573 15.7093V18.6424C69.5573 19.6335 69.1383 20.4022 68.3421 20.827L69.8297 26.1875H67.6506L66.2677 21.2114H65.5972V26.1875H63.4181V13.1605H66.582C68.5306 13.1605 69.5573 14.1315 69.5573 15.7093ZM59.3532 19.411C59.8771 19.411 60.1494 19.1481 60.1494 18.6424H60.1704V15.7093C60.1704 15.2036 59.898 14.9406 59.3742 14.9406H58.3894V19.411H59.3532ZM56.2103 13.1605H59.3742C61.3228 13.1605 62.3285 14.1112 62.3495 15.7295V18.6626C62.3495 20.2404 61.3228 21.2114 59.3742 21.2114H58.3894V26.1875H56.2103V13.1605ZM50.7834 23.6792C50.6577 24.6906 52.7111 24.6906 52.5854 23.6792V15.6486C52.6902 14.6372 50.6577 14.6372 50.7834 15.6486V23.6792ZM48.6043 15.6486C48.6043 14.0708 49.6939 13.0391 51.6844 13.0391C53.654 13.0391 54.7645 14.0708 54.7645 15.6486V23.6792C54.7645 25.257 53.675 26.2887 51.6844 26.2887C49.6939 26.2887 48.6043 25.2368 48.6043 23.6792V15.6486ZM43.3242 23.6792C43.1985 24.6906 45.2519 24.6906 45.1261 23.6792V15.6486C45.2309 14.6372 43.1985 14.6372 43.3242 15.6486V23.6792ZM41.1451 15.6486C41.1451 14.0708 42.2346 13.0391 44.2252 13.0391C46.2157 13.0391 47.3053 14.0708 47.3053 15.6486V23.6792C47.3053 25.257 46.2157 26.2887 44.2252 26.2887C42.2346 26.2887 41.1451 25.2368 41.1451 23.6792V15.6486Z'
        fill-rule='evenodd'
      />
    </svg>`,
  youtubeIcon: ` <svg width='24'
        height='24'
        viewBox='0 0 24 24'
        fill='none'
      >
        <path
          fill-rule ='evenodd'
          clip-rule='evenodd'
          d='M22.5417 12C22.5417 17.822 17.822 22.5417 12 22.5417C6.178 22.5417 1.45833 17.822 1.45833 12C1.45833 6.178 6.178 1.45833 12 1.45833C17.822 1.45833 22.5417 6.178 22.5417 12ZM23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM18.1111 12C18.1111 12 18.1111 9.72667 17.8318 8.63767C17.6784 8.03756 17.225 7.56456 16.6475 7.402C15.6031 7.11111 12 7.11111 12 7.11111C12 7.11111 8.39872 7.11111 7.3525 7.402C6.77744 7.56211 6.32339 8.03572 6.16817 8.63767C5.88889 9.72667 5.88889 12 5.88889 12C5.88889 12 5.88889 14.2733 6.16817 15.3623C6.32156 15.9624 6.775 16.4354 7.3525 16.598C8.39872 16.8889 12 16.8889 12 16.8889C12 16.8889 15.6031 16.8889 16.6475 16.598C17.2226 16.4379 17.6766 15.9643 17.8318 15.3623C18.1111 14.2733 18.1111 12 18.1111 12ZM14.4444 12L10.7778 14.1389V9.86111L14.4444 12Z'
        />
     </svg>`,
  twitterIcon: `
    <svg width='24'
        height='24'
        viewBox='0 0 24 24'
        fill='none'
      >
        <path
          fill-rule ='evenodd'
          clip-rule='evenodd'
          d='M22.5417 12C22.5417 17.822 17.822 22.5417 12 22.5417C6.178 22.5417 1.45833 17.822 1.45833 12C1.45833 6.178 6.178 1.45833 12 1.45833C17.822 1.45833 22.5417 6.178 22.5417 12ZM23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM16.7095 9.93043C16.7145 10.0394 16.7165 10.1494 16.7165 10.2604C16.7165 13.6354 14.2725 17.5254 9.80347 17.5244C8.43047 17.5244 7.15347 17.0944 6.07747 16.3564C6.26747 16.3804 6.46147 16.3934 6.65747 16.3934C7.79547 16.3964 8.84347 15.9844 9.67547 15.2944C8.61247 15.2694 7.71447 14.5164 7.40547 13.4854C7.55347 13.5174 7.70547 13.5344 7.86247 13.5354C8.08347 13.5364 8.29847 13.5064 8.50247 13.4484C7.39047 13.2024 6.55247 12.1484 6.55247 10.8904V10.8574C6.88047 11.0554 7.25447 11.1764 7.65347 11.1944C7.00147 10.7224 6.57247 9.92243 6.57247 9.02243C6.57247 8.54643 6.69247 8.10243 6.90147 7.72243C8.09947 9.30843 9.89047 10.3604 11.9115 10.4904C11.8695 10.3014 11.8485 10.1054 11.8485 9.90343C11.8485 8.48243 12.9365 7.34843 14.2785 7.37043C14.9775 7.38243 15.6095 7.70343 16.0525 8.20743C16.6055 8.10143 17.1255 7.89743 17.5955 7.61243C17.4135 8.20543 17.0285 8.69943 16.5265 9.00843C17.0185 8.95343 17.4865 8.82243 17.9225 8.62643C17.5965 9.13343 17.1845 9.57643 16.7095 9.93043Z'
        />
     </svg>`,
  mediumIcon: `
    <svg width='24'
        height='24'
        viewBox='0 0 24 24'
        fill='none'
      >
        <path
          fill-rule ='evenodd'
          clip-rule='evenodd'
          d='M22.5417 12C22.5417 17.822 17.822 22.5417 12 22.5417C6.178 22.5417 1.45833 17.822 1.45833 12C1.45833 6.178 6.178 1.45833 12 1.45833C17.822 1.45833 22.5417 6.178 22.5417 12ZM23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM17.7337 16.4862L16.8583 15.6117H16.8593C16.7676 15.5658 16.7217 15.4274 16.7217 15.3358V8.33883C16.7217 8.24717 16.7676 8.10875 16.8593 8.01708L17.7337 7.00417V6.95833H14.6033L12.2548 12.8965L9.5855 6.95833H6.36342V7.00417L7.193 8.15642C7.37633 8.33975 7.42217 8.61658 7.42217 8.84667V13.9085C7.468 14.1853 7.42217 14.508 7.28467 14.783L6.04167 16.4862V16.532H9.35633V16.4862L8.11333 14.8298C7.97583 14.5529 7.92908 14.277 7.97583 13.9543V9.35267C7.99111 9.38322 8.00639 9.40359 8.02167 9.42396C8.05222 9.4647 8.08278 9.50544 8.11333 9.62767L11.2438 16.6246H11.2896L14.3274 9.03C14.2807 9.30592 14.2807 9.62767 14.2807 9.85867V15.2899C14.2807 15.4283 14.2348 15.52 14.1432 15.6117L13.2228 16.4862V16.532H17.7337V16.4862Z'
        />
     </svg>`,
  discordIcon: ` <svg width='24'
        height='24'
        viewBox='0 0 24 24'
        fill='none'
      >
        <path
          fill-rule ='evenodd'
          clip-rule='evenodd'
          d='M22.5417 12C22.5417 17.822 17.822 22.5417 12 22.5417C6.178 22.5417 1.45833 17.822 1.45833 12C1.45833 6.178 6.178 1.45833 12 1.45833C17.822 1.45833 22.5417 6.178 22.5417 12ZM23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM10.7503 15.4042C10.6021 15.3766 10.4546 15.3449 10.3081 15.3092V15.3083L9.3882 16.3442C7.31174 16.2766 6.5124 14.8862 6.5124 14.8862C6.5124 11.7976 7.86626 9.29449 7.86626 9.29449C9.21828 8.25854 10.5064 8.28686 10.5064 8.28686L10.9101 8.76647C11.6111 8.66738 12.3223 8.66431 13.0241 8.75733C13.0583 8.75866 13.0924 8.76171 13.1264 8.76647L13.4945 8.28686C13.4945 8.28686 14.7817 8.25854 16.1346 9.29357C16.1346 9.29357 17.4876 11.7976 17.4876 14.8862C17.4876 14.8862 16.6983 16.2775 14.6218 16.3442L13.7805 15.2507C13.5238 15.3192 13.3246 15.3677 13.1839 15.3951C12.3806 15.5525 11.5547 15.5556 10.7503 15.4042ZM14.7972 12.9523C14.7972 12.4498 14.3633 12.0387 13.8143 12.0387C13.2652 12.0387 12.8231 12.4498 12.8322 12.9523C12.8322 13.4547 13.2661 13.8658 13.8143 13.8658C14.3542 13.8658 14.7972 13.4547 14.7972 12.9523ZM11.281 12.9523C11.281 12.4498 10.8471 12.0387 10.299 12.0387C9.74996 12.0387 9.31603 12.4498 9.31603 12.9523C9.31603 13.4547 9.74996 13.8658 10.299 13.8658C10.838 13.8658 11.281 13.4547 11.281 12.9523Z'
        />
     </svg>`,
}

const resources = {
  en_US: {
    common: {
      labelNavPro: 'Loopring pro',
      labelNavEarn: 'Loopring lite',
      labelNavWallet: 'Wallet',
      labelNavLanuch: 'View Dapps',
      labelLoopringSmartWallet: 'Loopring Smart Wallet',
      labelLoopringSmartWalletDes:
        'Your Gateway to Ethereum, DeFi, NFTs, and <br/>Financial Freedom',
      labelAbout: 'About',
      labelLoopringOrg: 'Loopring.org',
      labelLoopringTerms: 'Terms of Service',
      labelPrivacyPolicy: 'Privacy Policy',
      labelRiskDisclosure: 'Risk Disclosure',
      labelSupport: 'Support',
      labelSubmitARequest: '❤️ Submit a Request',
      labelCreatorGrants: 'Creator Grants',
      labelListAToken: 'List a Token',
      labelWalletGuardian: 'Wallet Guardian',
      labelPlatform: 'Platform',
      labelFees: 'Fees',
      labelVIPProgram: 'VIP Program',
      labelReferrals: 'Referrals',
      labelDevelopers: 'Developers',
      labelSmartContracts: 'Smart Contracts',
      labelAPIs: 'APIs',
      labelLayer2Explorer: 'Layer 2 Explorer',
      labelBugBounty: 'Bug Bounty',
      labelSubgraph: 'Subgraph',
      labelFollowus: 'Follow us',
      labelEthereumUnleashed: "<span>Ethereum's First zkRollup</span> <span>Layer2</span>",
      labelGatewayToEthereum:
        'Your gateway to Ethereum, DeFi, NFTs, and Financial Freedom.<br/> Fast, Low-cost, & Secure',
      labelCopyRight: '© 2017 Loopring Technology Limited. All rights reserved.',
      labelLearnMore: 'Learn More',
      labelLoopringProtocol: 'Loopring Protocol',
      labelLoopringProtocolDes:
        "The world's first ZKRollup implementation designed to scale Ethereum, fully optimized for trading.",
      labelUltimateSecurity: 'Ultimate Security',
      labelUltimateSecurityDes:
        'Assets on Loopring L2 are equally secure as they are on the Ethereum mainnet.',
      labelLowTransactionFees: 'Low Transaction Fees',
      labelLowTransactionFeesDes:
        'Loopring performs most operations, including trade and transfer settlement, off the Ethereum blockchain. This dramatically reduces gas consumption and overall transaction cost to small fractions of comparable on-chain cost.',
      labelHighThroughput: 'High Throughput',
      labelHighThroughputDes:
        'Loopring L2 can settle ~2000 transactions per second with near instant finality.',
      labelReadyForDevelopers: 'Ready for Developers',
      labelReadyForDevelopersDes:
        "Build scalable payment apps, non-custodial exchanges, and NFT marketplaces on Ethereum with Loopring's battle-tested zkRollup technology. Get started with quick-start guides, protocol documentation, a Javascript SDK, and a fully open source codebase.",
      labelFeatureDes8: 'Loopring Layer2',
      labelFeatureDes8_2: 'Crypto exchange on the go',
    },
  },
  // zh_CN: {...zhCN},
}

// const initLng = JSON.parse(localStorage.getItem('persist:settings') as string)?.language === `"${LanguageType.zh_CN}"` ? LanguageType.zh_CN : LanguageType.en_US
const initLng = 'en_US'
console.log('en_US')
const settingPersist = 'persist:settings'
let referralcodeStr = ''
;(function init() {
  let themeMode = 'dark'
  let settingPersistJson = localStorage.getItem(settingPersist)
  let settings = JSON.parse(settingPersistJson ? settingPersistJson : '{}')
  if (settings.themeMode && JSON.parse(settings.themeMode)) {
    themeMode = JSON.parse(settings.themeMode)
  }
  const onColorChange = (value = 'dark', _this) => {
    settings.themeMode = JSON.stringify(value)
    window.localStorage.setItem(settingPersist, JSON.stringify(settings))
    let link = document.getElementById('themeModeCss')
    link.setAttribute('href', value !== 'light' ? './css-dark.css' : './css-light.css')
    if (_this) {
      _this.setAttribute('value', value)
    }
  }
  const onColorChangeLoaded = (value = 'dark') => {
    const basicUrl = 'https://static.loopring.io/assets/images/landPage/'
    const imageEnd = value !== 'light' ? '.png' : '_light' + '.png'
    document.getElementById('changeColor').innerHTML =
      value !== 'light' ? svgGroup.DarkIcon : svgGroup.LightIcon
    document.getElementById('changeColor').setAttribute('data-theme', themeMode)
    document.getElementById('mobileBg').setAttribute('src', './mobile' + imageEnd)
  }

  onColorChange(themeMode !== 'dark' ? 'light' : 'dark')
  window.onGlobalChange = () => {
    themeMode = themeMode !== 'dark' ? 'dark' : 'light'
    onColorChange(themeMode)
    onColorChangeLoaded(themeMode)
  }
  // Language now english only
  const onlanguagechange = (value) => {
    let settingPersistJson = localStorage.getItem(settingPersist)
    let settings = JSON.parse(settingPersistJson ? settingPersistJson : '{}')
    settings.language = value
    window.localStorage.setItem(settingPersist, JSON.stringify(settings))
    i18next.changeLanguage('en_US')
  }
  const updateI18n = () => {
    document.getElementById('labelNavPro').innerHTML = i18next.t('labelNavPro')
    document.getElementById('labelNavEarn').innerHTML = i18next.t('labelNavEarn')
    document.getElementById('labelNavWallet').innerHTML = i18next.t('labelNavWallet')
    document.getElementById('labelNavLanuch').innerHTML = i18next.t('labelNavLanuch')
    document.getElementById('labelLearnMore').innerHTML = i18next.t('labelLearnMore')
    document.getElementById('labelLoopringSmartWallet').innerHTML = i18next.t(
      'labelLoopringSmartWallet',
    )
    document.getElementById('labelLoopringSmartWalletDes').innerHTML = i18next.t(
      'labelLoopringSmartWalletDes',
    )

    document.getElementById('labelAbout').innerHTML = i18next.t('labelAbout')
    document.getElementById('labelLoopringOrg').innerHTML = i18next.t('labelLoopringOrg')
    document.getElementById('labelLoopringTerms').innerHTML = i18next.t('labelLoopringTerms')
    document.getElementById('labelPrivacyPolicy').innerHTML = i18next.t('labelPrivacyPolicy')
    document.getElementById('labelRiskDisclosure').innerHTML = i18next.t('labelRiskDisclosure')
    document.getElementById('labelSupport').innerHTML = i18next.t('labelSupport')
    document.getElementById('labelSubmitARequest').innerHTML = i18next.t('labelSubmitARequest')
    document.getElementById('labelCreatorGrants').innerHTML = i18next.t('labelCreatorGrants')
    document.getElementById('labelListAToken').innerHTML = i18next.t('labelListAToken')
    document.getElementById('labelWalletGuardian').innerHTML = i18next.t('labelWalletGuardian')
    document.getElementById('labelPlatform').innerHTML = i18next.t('labelPlatform')
    document.getElementById('labelFees').innerHTML = i18next.t('labelFees')
    document.getElementById('labelVIPProgram').innerHTML = i18next.t('labelVIPProgram')
    document.getElementById('labelReferrals').innerHTML = i18next.t('labelReferrals')
    document.getElementById('labelDevelopers').innerHTML = i18next.t('labelDevelopers')
    document.getElementById('labelSmartContracts').innerHTML = i18next.t('labelSmartContracts')
    document.getElementById('labelAPIs').innerHTML = i18next.t('labelAPIs')
    document.getElementById('labelLayer2Explorer').innerHTML = i18next.t('labelLayer2Explorer')
    document.getElementById('labelBugBounty').innerHTML = i18next.t('labelBugBounty')
    document.getElementById('labelSubgraph').innerHTML = i18next.t('labelSubgraph')
    document.getElementById('labelFollowus').innerHTML = i18next.t('labelFollowus')
    document.getElementById('labelFeatureDes8').innerHTML = i18next.t('labelFeatureDes8')
    document.getElementById('labelFeatureDes8_2').innerHTML = i18next.t('labelFeatureDes8_2')

    document.getElementById('labelEthereumUnleashed').innerHTML =
      i18next.t('labelEthereumUnleashed')
    document.getElementById('labelGatewayToEthereum').innerHTML =
      i18next.t('labelGatewayToEthereum')
    // document.getElementById('labelIOS').innerHTML = i18next.t('labelIOS')
    // document.getElementById('labelAndroid').innerHTML = i18next.t('labelAndroid')
    // document.getElementById('labelGooglePlay').innerHTML = i18next.t('labelGooglePlay')
    // document.getElementById('labelIOS2').innerHTML = i18next.t('labelIOS')
    // document.getElementById('labelAndroid2').innerHTML = i18next.t('labelAndroid')
    // document.getElementById('labelGooglePlay2').innerHTML = i18next.t('labelGooglePlay')
    document.getElementById('labelCopyRight').innerHTML = i18next.t('labelCopyRight')
    document.getElementById('labelLoopringProtocol').innerHTML = i18next.t('labelLoopringProtocol')
    document.getElementById('labelLoopringProtocolDes').innerHTML = i18next.t(
      'labelLoopringProtocolDes',
    )
    document.getElementById('labelReadyForDevelopers').innerHTML =
      i18next.t('labelReadyForDevelopers')
    document.getElementById('labelReadyForDevelopersDes').innerHTML = i18next.t(
      'labelReadyForDevelopersDes',
    )
    document.getElementById('labelLearnMore3').innerHTML = i18next.t('labelLearnMore')
  }

  const upLoadSvg = () => {
    document.getElementById('logSvg').innerHTML = svgGroup.logSvg
    // document.getElementById('iconIos').innerHTML = svgGroup.ios
    // document.getElementById('iconAndroid').innerHTML = svgGroup.android
    // document.getElementById('iconGooglePlay').innerHTML = svgGroup.googlePlay
    // document.getElementById('iconIos2').innerHTML = svgGroup.ios
    // document.getElementById('iconAndroid2').innerHTML = svgGroup.android
    // document.getElementById('iconGooglePlay2').innerHTML = svgGroup.googlePlay
    document.getElementById('youtubeIcon').innerHTML = svgGroup.youtubeIcon
    document.getElementById('twitterIcon').innerHTML = svgGroup.twitterIcon
    document.getElementById('mediumIcon').innerHTML = svgGroup.mediumIcon
    document.getElementById('discordIcon').innerHTML = svgGroup.discordIcon
  }

  window.onload = () => {
    i18next
      // .use(i18nextHttpBackend)
      .use(i18nextBrowserLanguageDetector)
      .init(
        {
          resources,
          debug: false,
          ns: ['common'],
          defaultNS: 'common',
          lng: initLng,
          fallbackLng: initLng,
          keySeparator: '.', // we do not use keys in form messages.welcome
          interpolation: {
            escapeValue: true, // react already safes from xss
            formatSeparator: `, `,
          },
        },
        function (err, t) {
          // init set content
          updateI18n()
        },
      )
    var i18nLng = window.localStorage.getItem('lng')
    if (!i18nLng) {
      i18nLng = 'en'
    }
    upLoadSvg()
    onlanguagechange(i18nLng)
    onColorChangeLoaded(themeMode)
    let searchParam = window.location.search
    const searchParams = new URLSearchParams(searchParam)
    if (searchParams.get('referralcode')) {
      const referralcode = searchParams.get('referralcode')
      document
        .getElementById('logo')
        .setAttribute('href', 'https://loopring.io/#/?referralcode=' + referralcode)
      document
        .getElementById('labelNavLanuch')
        .setAttribute('href', 'https://loopring.io/#/?referralcode=' + referralcode)
      referralcodeStr
    }
    document.getElementById('detailBox').addEventListener('click', (e) => {
      ;[].slice.call(e.currentTarget.getElementsByClassName('flexBox')).map((ele) => {
        if (e.target.closest('div').id == ele.id) {
          ele.className = 'xs-12 md-8 flexBox flex-column selected'
        } else {
          ele.className = 'xs-12 md-2 flexBox flex-column'
        }
        // ele.classList.filter()
      }, true)

      // e.currentTarget.getElementsByClassName('flexBox')
      // debugger
      // e.('')
    })

    // const handleOnClick = () => {
    //   const imgs = document.getElementsByClassName('scroll-up-img')
    //   for (let index = 0; index < imgs.length; index++) {
    //     const img = imgs.item(index)
    //     if (img.getBoundingClientRect().top < window.innerHeight) {
    //       img.style.opacity = 1
    //       img.style.transform = 'translateY(0)'
    //     }
    //   }
    // }
    // setTimeout(() => {
    //   handleScroll()
    // }, 50)
    //
    // window.addEventListener('scroll', handleScroll)
    let clear = -1
    var options = document.getElementsByName('slider') //.options;

    // function loopScroll() {
    //   if (clear !== -1) {
    //     clearTimeout(clear)
    //   }
    //   let i = [].slice.call(options).findIndex((item) => item.checked == true)
    //   let next = i + 1
    //   options[options.length - next > 0 ? next : 0].checked = true
    //   clear = setTimeout(() => {
    //     if (window.innerWidth < 768) {
    //       loopScroll()
    //     }
    //   }, 3000)
    // }
    //
    // loopScroll()
  }
})()
